using System;
using System.Runtime.InteropServices;

namespace ledger
{
 // This file intentionally contains simple vulnerability patterns for testing static analyzers.
 // Do NOT use in production.
 public static class Vulnerabilities
 {
 //1) Memory leak: allocate unmanaged memory and do not free it.
 // True issue: native memory will not be released until process exit.
 public static void LeakNativeMemory()
 {
 IntPtr ptr = Marshal.AllocHGlobal(1024);
 // ... use ptr
 // intentionally forget to call Marshal.FreeHGlobal(ptr);
 Console.WriteLine("Allocated native memory at: " + ptr);
 }

 //2) Double free (double FreeHGlobal) - can corrupt heap at runtime
 // True issue: calling FreeHGlobal twice on the same pointer is undefined.
 public static void DoubleFree()
 {
 IntPtr ptr = Marshal.AllocHGlobal(128);
 try
 {
 // use ptr
 }
 finally
 {
 Marshal.FreeHGlobal(ptr);
 // erroneous double free
 try
 {
 Marshal.FreeHGlobal(ptr);
 }
 catch (Exception ex)
 {
 // swallow so program continues during tests
 Console.WriteLine("Second free failed: " + ex.Message);
 }
 }
 }

 //3) Null reference dereference: intentionally dereference a possibly-null object
 // True issue: can throw NullReferenceException at runtime
 public static int NullDeref(string maybeNull)
 {
 // intentionally not checking for null
 // will throw if maybeNull is null
 return maybeNull.Length;
 }

 //4) Dispose not called (resource leak): create disposable and don't dispose
 // True issue: stream stays undisposed
 public static void ForgotToDispose()
 {
 var fs = System.IO.File.OpenRead("nonexistent.txt");
 // intentionally not disposing fs
 Console.WriteLine(fs.Length);
 }
 }
}
