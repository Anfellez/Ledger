﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ledger
{
    public partial class Form1 : Form
    {
        private BindingList<Transaction> _bindingList = new BindingList<Transaction>();
        private List<Transaction> _allTransactions = new List<Transaction>();

        // exchange rates relative to base currency
        private Dictionary<string, decimal> _exchangeRates = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase)
        {
            { "CNY",1m },
            { "USD",7.0m },
            { "EUR",7.5m },
            { "JPY",0.05m }
        };

        private string _baseCurrency = "CNY";
        private ComboBox comboBoxBaseCurrency;

        public Form1()
        {
            InitializeComponent();
            InitializeCustomLogic();
        }

        private void InitializeCustomLogic()
        {
            // DataGridView setup
            dataGridViewTransactions.AutoGenerateColumns = false;

            // Add basic columns if none defined
            if (dataGridViewTransactions.Columns.Count == 0)
            {
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Date", HeaderText = "日期", Width = 120 });
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Type", HeaderText = "类型", Width = 80 });
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Amount", HeaderText = "金额", Width = 100 });
                // show currency column
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Currency", HeaderText = "币种", Width = 60 });
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Counterparty", HeaderText = "交易对象", Width = 120 });
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Category", HeaderText = "分类", Width = 120 });
                dataGridViewTransactions.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Remark", HeaderText = "备注", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            }

            dataGridViewTransactions.DataSource = _bindingList;

 // --- Visual improvements for better UX (muted palette) ---
 try
 {
 // Top buttons styling (muted colors)
 var btnFont = new Font("Segoe UI",9F, FontStyle.Regular);
 Action<Button, Color, Color> styleButton = (b, back, fore) =>
 {
 b.FlatStyle = FlatStyle.Flat;
 b.FlatAppearance.BorderSize =0;
 b.BackColor = back;
 b.ForeColor = fore;
 b.Font = btnFont;
 b.Cursor = Cursors.Hand;
 };

 Color mutedGreen = Color.FromArgb(88,140,99);
 Color mutedAmber = Color.FromArgb(170,140,80);
 Color mutedRed = Color.FromArgb(170,80,78);
 Color mutedBlue = Color.FromArgb(80,130,170);
 Color mutedGray = Color.FromArgb(120,120,120);

 styleButton(btnAdd, mutedGreen, Color.White);
 styleButton(btnEdit, mutedAmber, Color.White);
 styleButton(btnDelete, mutedRed, Color.White);
 styleButton(btnSave, mutedBlue, Color.White);
 styleButton(btnLoad, mutedGray, Color.White);

 // Tooltips (no change)
 var toolTip = new ToolTip();
 toolTip.SetToolTip(btnAdd, "新增一条交易记录");
 toolTip.SetToolTip(btnEdit, "编辑选中的交易记录");
 toolTip.SetToolTip(btnDelete, "删除选中的交易记录");
 toolTip.SetToolTip(btnSave, "将当前数据保存到文件");
 toolTip.SetToolTip(btnLoad, "从文件加载交易数据");

 // Filter panel styling (subtle)
 panelFilter.BackColor = Color.FromArgb(248,250,252);
 panelFilter.Padding = new Padding(8);

 // Make filter labels more readable
 foreach (Control c in panelFilter.Controls)
 {
 if (c is Label lbl)
 {
 lbl.Font = new Font("Segoe UI",9F, FontStyle.Regular);
 lbl.ForeColor = Color.FromArgb(80,80,80);
 }
 }

 // DataGridView styling: white and pale-blue alternating rows
 dataGridViewTransactions.EnableHeadersVisualStyles = false;
 dataGridViewTransactions.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(95,135,165);
 dataGridViewTransactions.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
 dataGridViewTransactions.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI",9F, FontStyle.Bold);
 dataGridViewTransactions.RowHeadersVisible = false;
 dataGridViewTransactions.DefaultCellStyle.BackColor = Color.White;
 dataGridViewTransactions.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240,248,255); // pale blue
 dataGridViewTransactions.DefaultCellStyle.SelectionBackColor = Color.FromArgb(210,225,235);
 dataGridViewTransactions.DefaultCellStyle.SelectionForeColor = Color.Black;
 dataGridViewTransactions.GridColor = Color.FromArgb(220,230,235);
 dataGridViewTransactions.RowTemplate.Height =36;

 // Status strip styling
 try { statusStrip1.Font = new Font("Segoe UI",9F, FontStyle.Regular); } catch { }
 }
 catch
 {
 // silently ignore styling errors on unexpected environments
 }

            // add base currency combobox to filter panel (minimal intrusion)
            comboBoxBaseCurrency = new ComboBox();
            comboBoxBaseCurrency.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxBaseCurrency.Items.AddRange(new object[] { "CNY", "USD", "EUR", "JPY" });
            comboBoxBaseCurrency.SelectedItem = _baseCurrency;
            comboBoxBaseCurrency.Location = new Point(1120,52);
            comboBoxBaseCurrency.Size = new Size(80,24);
            comboBoxBaseCurrency.SelectedIndexChanged += (s, e) =>
            {
                _baseCurrency = comboBoxBaseCurrency.Text;
                // update amount label to indicate filter unit
                try { labelAmount.Text = $"金额（{_baseCurrency}）："; } catch { }
                UpdateStatusSummary();
            };
            panelFilter.Controls.Add(comboBoxBaseCurrency);

            // Wire up button events
            btnAdd.Click += BtnAdd_Click;
            btnEdit.Click += BtnEdit_Click;
            btnDelete.Click += BtnDelete_Click;
            btnSave.Click += BtnSave_Click;
            btnLoad.Click += BtnLoad_Click;

            dataGridViewTransactions.CellDoubleClick += DataGridViewTransactions_CellDoubleClick;

            // Filter events
            btnApplyFilter.Click += BtnApplyFilter_Click;
            btnClearFilter.Click += BtnClearFilter_Click;
            chkDateFilter.CheckedChanged += FilterOptionsChanged;
            chkAmountFilter.CheckedChanged += FilterOptionsChanged;
            comboBoxTypeFilter.SelectedIndexChanged += FilterOptionsChanged;
            dateTimePickerFrom.ValueChanged += FilterOptionsChanged;
            dateTimePickerTo.ValueChanged += FilterOptionsChanged;
            numAmountMin.ValueChanged += FilterOptionsChanged;
            numAmountMax.ValueChanged += FilterOptionsChanged;

            // init sample data or load
            LoadTransactionsSample();
            UpdateStatusSummary();
            UpdateFilterControlsState();
        }

        private void LoadTransactionsSample()
        {
            // keep empty initial list; you may replace with real load
            _allTransactions = new List<Transaction>();
            _bindingList = new BindingList<Transaction>(_allTransactions);
            dataGridViewTransactions.DataSource = _bindingList;
        }

        private void DataGridViewTransactions_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            EditSelected();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var form = new TransactionForm(new Transaction());
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                // only add to master list, then refresh the current view (handles filtered/unfiltered cases)
                _allTransactions.Add(form.Transaction);
                ApplyFilters();
                // select the newly added item in the grid if visible
                for (int i = 0; i < dataGridViewTransactions.Rows.Count; i++)
                {
                    var item = dataGridViewTransactions.Rows[i].DataBoundItem as Transaction;
                    if (item != null && item.Id == form.Transaction.Id)
                    {
                        dataGridViewTransactions.ClearSelection();
                        dataGridViewTransactions.Rows[i].Selected = true;
                        try { dataGridViewTransactions.FirstDisplayedScrollingRowIndex = i; } catch { }
                        break;
                    }
                }
                UpdateStatusSummary();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            EditSelected();
        }

        private void EditSelected()
        {
            if (dataGridViewTransactions.CurrentRow == null) return;
            var t = dataGridViewTransactions.CurrentRow.DataBoundItem as Transaction;
            if (t == null) return;

            // copy a temp
            var temp = new Transaction
            {
                Id = t.Id,
                Date = t.Date,
                Amount = t.Amount,
                Type = t.Type,
                Counterparty = t.Counterparty,
                Category = t.Category,
                Remark = t.Remark
            };

            var form = new TransactionForm(temp);
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                // apply to master list
                var idx = _allTransactions.FindIndex(x => x.Id == t.Id);
                if (idx >= 0)
                {
                    _allTransactions[idx].Date = form.Transaction.Date;
                    _allTransactions[idx].Amount = form.Transaction.Amount;
                    _allTransactions[idx].Type = form.Transaction.Type;
                    _allTransactions[idx].Counterparty = form.Transaction.Counterparty;
                    _allTransactions[idx].Category = form.Transaction.Category;
                    _allTransactions[idx].Remark = form.Transaction.Remark;
                }

                // refresh current view (may be filtered)
                ApplyFilters();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewTransactions.CurrentRow == null) return;
            var t = dataGridViewTransactions.CurrentRow.DataBoundItem as Transaction;
            if (t == null) return;
            if (MessageBox.Show(this, "确认删除选中的记录？", "删除", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                // remove from master list and refresh view
                _allTransactions.RemoveAll(x => x.Id == t.Id);
                ApplyFilters();
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            // Save _allTransactions to XML (no external packages required)
            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "XML 文件 (*.xml)|*.xml|所有文件 (*.*)|*.*";
                dlg.DefaultExt = "xml";
                dlg.FileName = "transactions.xml";
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        var serializer = new XmlSerializer(typeof(List<Transaction>));
                        using (var fs = File.Create(dlg.FileName))
                        {
                            serializer.Serialize(fs, _allTransactions);
                        }
                        MessageBox.Show(this, "保存成功。", "信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, $"保存失败：{ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            // Load list from XML and replace master list, then refresh view
            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "XML 文件 (*.xml)|*.xml|所有文件 (*.*)|*.*";
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        var serializer = new XmlSerializer(typeof(List<Transaction>));
                        List<Transaction> loaded;
                        using (var fs = File.OpenRead(dlg.FileName))
                        {
                            loaded = (List<Transaction>)serializer.Deserialize(fs);
                        }
                        _allTransactions = loaded ?? new List<Transaction>();
                        ApplyFilters();
                        MessageBox.Show(this, "加载成功。", "信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, $"加载失败：{ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void BtnApplyFilter_Click(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void BtnClearFilter_Click(object sender, EventArgs e)
        {
            // reset filter controls
            chkDateFilter.Checked = false;
            chkAmountFilter.Checked = false;
            comboBoxTypeFilter.SelectedIndex = 0;
            dateTimePickerFrom.Value = DateTime.Today.AddMonths(-1);
            dateTimePickerTo.Value = DateTime.Today;
            numAmountMin.Value = 0;
            numAmountMax.Value = 0;

            ApplyFilters();
        }

        private void FilterOptionsChanged(object sender, EventArgs e)
        {
            UpdateFilterControlsState();
        }

        private void UpdateFilterControlsState()
        {
            // enable/disable controls based on checkboxes
            dateTimePickerFrom.Enabled = chkDateFilter.Checked;
            dateTimePickerTo.Enabled = chkDateFilter.Checked;
            numAmountMin.Enabled = chkAmountFilter.Checked;
            numAmountMax.Enabled = chkAmountFilter.Checked;

            // Enable apply button only if any filter active or type not All
            btnApplyFilter.Enabled = chkDateFilter.Checked || chkAmountFilter.Checked || (comboBoxTypeFilter.SelectedIndex > 0);
        }

        private void ApplyFilters()
        {
            IEnumerable<Transaction> query = _allTransactions;

            if (chkDateFilter.Checked)
            {
                var from = dateTimePickerFrom.Value.Date;
                var to = dateTimePickerTo.Value.Date.AddDays(1).AddTicks(-1);
                query = query.Where(x => x.Date >= from && x.Date <= to);
            }

            if (comboBoxTypeFilter.SelectedIndex == 1) // Income
            {
                query = query.Where(x => string.Equals(x.Type, "Income", StringComparison.OrdinalIgnoreCase));
            }
            else if (comboBoxTypeFilter.SelectedIndex == 2) // Expense
            {
                query = query.Where(x => string.Equals(x.Type, "Expense", StringComparison.OrdinalIgnoreCase));
            }

            if (chkAmountFilter.Checked)
            {
                var min = numAmountMin.Value;
                var max = numAmountMax.Value;
                if (min >0 || max >0)
                {
                    if (min >0) query = query.Where(x => { var conv = ConvertToBase(x.Amount, x.Currency); return conv >= min; });
                    if (max >0) query = query.Where(x => { var conv = ConvertToBase(x.Amount, x.Currency); return conv <= max; });
                }
            }

            var result = query.ToList();
            _bindingList = new BindingList<Transaction>(result);
            dataGridViewTransactions.DataSource = _bindingList;
            UpdateStatusSummary();
        }

        private decimal ConvertToBase(decimal amount, string currency)
        {
            if (string.IsNullOrWhiteSpace(currency)) currency = _baseCurrency;
            if (string.Equals(currency, _baseCurrency, StringComparison.OrdinalIgnoreCase)) return amount;
            if (_exchangeRates.TryGetValue(currency, out var rate))
            {
                // rate means 1 unit of currency = rate units of base currency
                return amount * rate;
            }
            // unknown currency, treat as base for safety
            return amount;
        }

        private void UpdateStatusSummary()
        {
            int count = _bindingList.Count;
            decimal sum = 0m;
            foreach (var t in _bindingList)
            {
                sum += ConvertToBase(t.Amount, t.Currency);
            }
            toolStripStatusLabelSummary.Text = $"共 {count} 条，收支合计：{sum:F2} {_baseCurrency}";
        }

        private void labelDateFrom_Click(object sender, EventArgs e)
        {

        }
    }
}
