using System;
using System.Windows.Forms;

namespace ledger
{
    public partial class TransactionForm : Form
    {
        public Transaction Transaction { get; private set; }

        public TransactionForm()
        {
            InitializeComponent();
        }

        public TransactionForm(Transaction t) : this()
        {
            Transaction = t ?? new Transaction();
            dateTimePickerDate.Value = Transaction.Date;
            comboBoxType.SelectedItem = Transaction.Type ?? "Expense";
            textBoxCounterparty.Text = Transaction.Counterparty;
            textBoxCategory.Text = Transaction.Category;
            numericUpDownAmount.Value = Transaction.Amount;
            textBoxRemark.Text = Transaction.Remark;
            // currency
            comboBoxCurrency.SelectedItem = Transaction.Currency ?? "CNY";
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            // Validation
            if (string.IsNullOrWhiteSpace(comboBoxType.Text))
            {
                MessageBox.Show(this, "��ѡ�� ����/֧�� ���͡�", "��֤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(textBoxCounterparty.Text))
            {
                MessageBox.Show(this, "�����뽻�׶���", "��֤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(textBoxCategory.Text))
            {
                MessageBox.Show(this, "��������ࡣ", "��֤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (numericUpDownAmount.Value <= 0)
            {
                MessageBox.Show(this, "���������0 �Ľ�", "��֤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // apply
            if (Transaction == null) Transaction = new Transaction();
            Transaction.Date = dateTimePickerDate.Value;
            Transaction.Type = comboBoxType.Text;
            Transaction.Counterparty = textBoxCounterparty.Text.Trim();
            Transaction.Category = textBoxCategory.Text.Trim();
            Transaction.Amount = numericUpDownAmount.Value;
            Transaction.Remark = textBoxRemark.Text.Trim();
            Transaction.Currency = comboBoxCurrency.Text;

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void InitializeComponent()
        {
            this.dateTimePickerDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.textBoxCounterparty = new System.Windows.Forms.TextBox();
            this.textBoxCategory = new System.Windows.Forms.TextBox();
            this.numericUpDownAmount = new System.Windows.Forms.NumericUpDown();
            this.textBoxRemark = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelCounterparty = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.labelRemark = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip();
            this.comboBoxCurrency = new System.Windows.Forms.ComboBox();
            this.labelCurrency = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAmount)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePickerDate
            // 
            this.dateTimePickerDate.Location = new System.Drawing.Point(120, 12);
            this.dateTimePickerDate.Name = "dateTimePickerDate";
            this.dateTimePickerDate.Size = new System.Drawing.Size(252, 28);
            // 
            // comboBoxType
            // 
            this.comboBoxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxType.Items.AddRange(new object[] { "Income", "Expense" });
            this.comboBoxType.Location = new System.Drawing.Point(120, 52);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(120, 28);
            this.comboBoxType.SelectedIndex = 1; // default Expense
            // 
            // textBoxCounterparty
            // 
            this.textBoxCounterparty.Location = new System.Drawing.Point(120, 92);
            this.textBoxCounterparty.Name = "textBoxCounterparty";
            this.textBoxCounterparty.Size = new System.Drawing.Size(252, 28);
            // 
            // textBoxCategory
            // 
            this.textBoxCategory.Location = new System.Drawing.Point(120, 132);
            this.textBoxCategory.Name = "textBoxCategory";
            this.textBoxCategory.Size = new System.Drawing.Size(180, 28);
            // 
            // numericUpDownAmount
            // 
            this.numericUpDownAmount.DecimalPlaces = 2;
            this.numericUpDownAmount.Maximum = new decimal(new int[] { 9999999, 0, 0, 0 });
            this.numericUpDownAmount.Location = new System.Drawing.Point(310, 132);
            this.numericUpDownAmount.Name = "numericUpDownAmount";
            this.numericUpDownAmount.Size = new System.Drawing.Size(62, 28);
            // 
            // textBoxRemark
            // 
            this.textBoxRemark.Location = new System.Drawing.Point(120, 212);
            this.textBoxRemark.Name = "textBoxRemark";
            this.textBoxRemark.Size = new System.Drawing.Size(252, 28);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(216, 252);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 30);
            this.btnOk.Text = "ȷ��";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(297, 252);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 30);
            this.btnCancel.Text = "ȡ��";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(12, 16);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(88, 18);
            this.labelDate.Text = "����ʱ�䣺";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(12, 56);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(96, 18);
            this.labelType.Text = "��֧���ͣ�";
            // 
            // labelCounterparty
            // 
            this.labelCounterparty.AutoSize = true;
            this.labelCounterparty.Location = new System.Drawing.Point(12, 96);
            this.labelCounterparty.Name = "labelCounterparty";
            this.labelCounterparty.Size = new System.Drawing.Size(96, 18);
            this.labelCounterparty.Text = "���׶���";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(12, 136);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(56, 18);
            this.labelCategory.Text = "���ࣺ";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(260, 136);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(52, 18);
            this.labelAmount.Text = "��";
            // 
            // labelRemark
            // 
            this.labelRemark.AutoSize = true;
            this.labelRemark.Location = new System.Drawing.Point(12, 216);
            this.labelRemark.Name = "labelRemark";
            this.labelRemark.Size = new System.Drawing.Size(116, 18);
            this.labelRemark.Text = "��ע����ѡ����";
            // 
            // comboBoxCurrency
            // 
            this.comboBoxCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCurrency.Items.AddRange(new object[] { "CNY", "USD", "EUR", "JPY" });
            this.comboBoxCurrency.Location = new System.Drawing.Point(120, 172);
            this.comboBoxCurrency.Name = "comboBoxCurrency";
            this.comboBoxCurrency.Size = new System.Drawing.Size(100, 28);
            // 
            // labelCurrency
            // 
            this.labelCurrency.AutoSize = true;
            this.labelCurrency.Location = new System.Drawing.Point(12, 176);
            this.labelCurrency.Name = "labelCurrency";
            this.labelCurrency.Size = new System.Drawing.Size(88, 18);
            this.labelCurrency.Text = "���֣�";
            // 
            // toolTip1
            // 
            this.toolTip1.SetToolTip(this.dateTimePickerDate, "ѡ���׷��������ں�ʱ�䡣");
            this.toolTip1.SetToolTip(this.comboBoxType, "ѡ�������� (Income)����֧�� (Expense)��");
            this.toolTip1.SetToolTip(this.textBoxCounterparty, "��д���׵ĶԷ����׶������磺���С�΢�����ѡ���˾���Ƶȡ�");
            this.toolTip1.SetToolTip(this.textBoxCategory, "��д���ʽ��׵ķ��࣬���磺��������ͨ�����ʡ������ȡ�");
            this.toolTip1.SetToolTip(this.numericUpDownAmount, "��������������0����������λС������");
            this.toolTip1.SetToolTip(this.textBoxRemark, "��ѡ����д����˵����ע��");
            // 
            // TransactionForm
            // 
            this.ClientSize = new System.Drawing.Size(384, 294);
            this.Controls.Add(this.labelCurrency);
            this.Controls.Add(this.comboBoxCurrency);
            this.Controls.Add(this.labelRemark);
            this.Controls.Add(this.labelAmount);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.labelCounterparty);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.textBoxRemark);
            this.Controls.Add(this.numericUpDownAmount);
            this.Controls.Add(this.textBoxCategory);
            this.Controls.Add(this.textBoxCounterparty);
            this.Controls.Add(this.comboBoxType);
            this.Controls.Add(this.dateTimePickerDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TransactionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "���׼�¼";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAmount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DateTimePicker dateTimePickerDate;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.TextBox textBoxCounterparty;
        private System.Windows.Forms.TextBox textBoxCategory;
        private System.Windows.Forms.NumericUpDown numericUpDownAmount;
        private System.Windows.Forms.TextBox textBoxRemark;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelCounterparty;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelRemark;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox comboBoxCurrency;
        private System.Windows.Forms.Label labelCurrency;
    }
}